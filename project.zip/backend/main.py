"""
SK VIDEO ENHANCER - Production FastAPI Processing Server
Branding: SK MUZAMMEL 10K
Endpoints:
- POST /api/enhance: Upload and begin processing
- GET /api/jobs/{job_id}: Progress tracking
- GET /api/jobs/{job_id}/download: Download processed video
- DELETE /api/jobs/{job_id}: Cancel and clean up
- GET /health: Healthcheck
"""

import os
import uuid
import time
import shutil
import logging
from typing import Dict, Any
from fastapi import FastAPI, UploadFile, File, Form, BackgroundTasks, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from enhancer import process_video_pipeline, probe_video

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sk_enhancer_api")

app = FastAPI(
    title="SK VIDEO ENHANCER API",
    description="Commercial AI Video Enhancement API with SK MUZAMMEL 10K branding",
    version="1.0.0"
)

# Enable CORS for Android clients and web frontends
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "/tmp/sk_enhancer/uploads"
OUTPUT_DIR = "/tmp/sk_enhancer/outputs"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# In-memory job state repository
jobs: Dict[str, Dict[str, Any]] = {}

class JobResponse(BaseModel):
    job_id: str
    status: str
    progress: float
    stage: str
    original_resolution: str
    target_resolution: str
    watermark_applied: bool
    download_url: str = None
    error_message: str = None

def run_enhancement_task(
    job_id: str,
    input_path: str,
    output_path: str,
    target_resolution: str,
    model: str,
    fps_60: bool,
    watermark: bool
):
    try:
        def update_progress(prog: float, stage: str):
            if job_id in jobs:
                jobs[job_id]["progress"] = prog
                jobs[job_id]["stage"] = stage

        jobs[job_id]["status"] = "PROCESSING"
        process_video_pipeline(
            input_path=input_path,
            output_path=output_path,
            target_resolution=target_resolution,
            model=model,
            fps_60=fps_60,
            watermark=watermark,
            progress_callback=update_progress
        )

        jobs[job_id]["status"] = "COMPLETED"
        jobs[job_id]["progress"] = 1.0
        jobs[job_id]["stage"] = "Enhancement complete! Ready to download."
        jobs[job_id]["download_url"] = f"/api/jobs/{job_id}/download"
        logger.info(f"Job {job_id} successfully completed.")

    except Exception as e:
        logger.error(f"Job {job_id} failed: {e}", exc_info=True)
        if job_id in jobs:
            jobs[job_id]["status"] = "FAILED"
            jobs[job_id]["error_message"] = str(e)
            jobs[job_id]["stage"] = f"Failed: {str(e)}"

@app.get("/health")
def health_check():
    ffmpeg_found = shutil.which("ffmpeg") is not None
    return {
        "status": "healthy",
        "service": "SK VIDEO ENHANCER (SK MUZAMMEL 10K)",
        "ffmpeg_available": ffmpeg_found,
        "ai_model_loaded": True,
        "version": "1.0.0"
    }

@app.post("/api/enhance", response_model=JobResponse)
async def create_enhancement_job(
    background_tasks: BackgroundTasks,
    video: UploadFile = File(...),
    target_resolution: str = Form("1080p FHD"),
    model: str = Form("Real-ESRGAN"),
    fps_60: bool = Form(True),
    watermark: bool = Form(True)
):
    # Validate file extension and MIME
    filename = video.filename or "video.mp4"
    ext = os.path.splitext(filename)[1].lower()
    if ext not in [".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported format '{ext}'. Please upload MP4, MOV, MKV, or WEBM."
        )

    job_id = f"SK-{uuid.uuid4().hex[:8].upper()}"
    input_file_path = os.path.join(UPLOAD_DIR, f"{job_id}{ext}")
    output_file_path = os.path.join(OUTPUT_DIR, f"enhanced_{job_id}.mp4")

    # Save uploaded file
    try:
        with open(input_file_path, "wb") as f:
            shutil.copyfileobj(video.file, f)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save upload: {e}")

    # Check file size
    size_bytes = os.path.getsize(input_file_path)
    if size_bytes == 0:
        os.remove(input_file_path)
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if size_bytes > 150 * 1024 * 1024:
        os.remove(input_file_path)
        raise HTTPException(status_code=400, detail="File exceeds 150MB limit.")

    # Probe original resolution
    info = probe_video(input_file_path)
    orig_res = f"{info['width']}x{info['height']}"

    jobs[job_id] = {
        "job_id": job_id,
        "status": "QUEUED",
        "progress": 0.05,
        "stage": "Job queued in processing cluster...",
        "original_resolution": orig_res,
        "target_resolution": target_resolution,
        "model": model,
        "fps_60": fps_60,
        "watermark_applied": watermark,
        "input_path": input_file_path,
        "output_path": output_file_path,
        "download_url": None,
        "error_message": None,
        "created_at": time.time()
    }

    background_tasks.add_task(
        run_enhancement_task,
        job_id=job_id,
        input_path=input_file_path,
        output_path=output_file_path,
        target_resolution=target_resolution,
        model=model,
        fps_60=fps_60,
        watermark=watermark
    )

    return JobResponse(
        job_id=job_id,
        status="QUEUED",
        progress=0.05,
        stage="Queued for AI enhancement",
        original_resolution=orig_res,
        target_resolution=target_resolution,
        watermark_applied=watermark
    )

@app.get("/api/jobs/{job_id}", response_model=JobResponse)
def get_job_status(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")

    return JobResponse(
        job_id=job_id,
        status=job["status"],
        progress=job["progress"],
        stage=job["stage"],
        original_resolution=job["original_resolution"],
        target_resolution=job["target_resolution"],
        watermark_applied=job["watermark_applied"],
        download_url=job["download_url"],
        error_message=job["error_message"]
    )

@app.get("/api/jobs/{job_id}/download")
def download_job_output(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    if job["status"] != "COMPLETED":
        raise HTTPException(
            status_code=400,
            detail=f"Video is not ready for download. Current status: {job['status']}"
        )

    output_path = job["output_path"]
    if not os.path.exists(output_path):
        raise HTTPException(status_code=500, detail="Processed video file is missing on server.")

    return FileResponse(
        path=output_path,
        media_type="video/mp4",
        filename=f"SK_MUZAMMEL_10K_ENHANCED_{job_id}.mp4"
    )

@app.delete("/api/jobs/{job_id}")
def cancel_job(job_id: str):
    job = jobs.get(job_id)
    if not job:
        return {"status": "ok", "message": "Job already removed."}

    job["status"] = "CANCELLED"
    job["stage"] = "Cancelled by user"

    # Clean up files
    for key in ["input_path", "output_path"]:
        path = job.get(key)
        if path and os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass

    del jobs[job_id]
    return {"status": "ok", "message": f"Job {job_id} cancelled and cleaned up."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
