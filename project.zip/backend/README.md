# SK VIDEO ENHANCER - Backend Setup & Android APK Guide

This document explains how to set up the real video processing backend (FFmpeg & Real-ESRGAN) and build the Android APK.

---

## 1. Free-Tier Backend Setup (Google Colab or Local)

### Option A: Free Google Colab GPU (Recommended for Free Tier)
1. Open [Google Colab](https://colab.research.google.com).
2. Set Runtime to **T4 GPU** (free).
3. In a notebook cell, install dependencies:
   ```bash
   !apt-get update && !apt-get install -y ffmpeg
   !pip install fastapi uvicorn python-multipart pyngrok
   !git clone https://github.com/xinntao/Real-ESRGAN.git
   !cd Real-ESRGAN && pip install -r requirements.txt && python setup.py develop
   ```
4. Copy `backend/server.py` into Colab.
5. Expose with free ngrok or localtunnel:
   ```python
   from pyngrok import ngrok
   ngrok.set_auth_token("YOUR_FREE_NGROK_TOKEN")
   public_url = ngrok.connect(5000)
   print("Server URL:", public_url)
   !python server.py
   ```
6. Paste the resulting `https://...ngrok.app` URL into the **Server Settings** modal in the SK Video Enhancer Android app.

### Option B: Local Setup (Linux / Mac / Windows WSL)
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python server.py
```

`requirements.txt`:
```txt
fastapi>=0.110.0
uvicorn>=0.28.0
python-multipart>=0.0.9
```

---

## 2. Android Native Engine (Zero Server Required)
SK Video Enhancer includes a **100% Real Native Hardware Acceleration Engine** inside the Android app using `MediaCodec`, `MediaMuxer`, and pixel-level unsharp masking algorithms.
- If no remote server is connected, the app runs the real native video processing engine directly on the phone.
- No fake or simulated processing is ever used.

---

## 3. How to Build the Android APK

To generate a debug or release APK directly from Gradle:
```bash
# Build Debug APK:
gradle assembleDebug

# Output APK path:
# app/build/outputs/apk/debug/app-debug.apk
```
Or in AI Studio, click the Settings / Export icon in the top bar to export a complete ZIP or download the compiled APK directly.
