# SK VIDEO ENHANCER - Backend Server & AI Engine
**Branding:** SK MUZAMMEL 10K  
**Version:** 1.0.0 (Commercial AI Video Upscaling Edition)

---

## Overview
This is the official processing backend for **SK VIDEO ENHANCER**. It provides real-time AI video enhancement using FFmpeg, Real-ESRGAN super-resolution neural pipelines, optical flow 60 FPS motion smoothing, and burns the signature watermark **SK MUZAMMEL 10K** (at 25% opacity in the bottom-right corner).

---

## API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/health` | Check backend status and FFmpeg / AI model availability |
| `POST` | `/api/enhance` | Upload video & start enhancement (target_resolution, model, fps_60, watermark) |
| `GET` | `/api/jobs/{job_id}` | Retrieve real-time progress percentage and stage descriptions |
| `GET` | `/api/jobs/{job_id}/download` | Download the verified enhanced output video file |
| `DELETE` | `/api/jobs/{job_id}` | Cancel job and remove temporary storage files |

---

## Local Setup & Execution

### 1. Requirements
- Python 3.10+
- FFmpeg installed (`apt install ffmpeg` on Ubuntu/Debian, `brew install ffmpeg` on macOS)

### 2. Installation
```bash
cd backend
pip install -r requirements.txt
```

### 3. Launch the Server
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
The server will start at `http://localhost:8000`.

---

## Docker Deployment

To build and run with Docker:
```bash
docker build -t sk-video-enhancer-backend .
docker run -d -p 8000:8000 --name sk-enhancer-server sk-video-enhancer-backend
```

---

## Connecting from Android App
1. Open **SK VIDEO ENHANCER** on your Android device or emulator.
2. Go to **Settings** (সেটিংস).
3. Set **Backend Server URL**:
   - For Android Emulator: `http://10.0.2.2:8000/`
   - For Physical Device on same Wi-Fi: `http://<your-computer-ip>:8000/`
   - For Cloud / VPS: `https://your-domain.com/`
4. Tap **Ping Server** to verify connection.
5. If running without a server, the app will seamlessly run in **Standalone Mode** directly on device.
