"""
SK VIDEO ENHANCER - Automated Pipeline Verification Suite
Branding: SK MUZAMMEL 10K
Tests:
1. Short MP4 video enhancement
2. Video with audio preservation
3. Unsupported / corrupted file rejection
4. Job progress polling & cancellation
5. Watermark burn verification & output download
"""

import os
import time
import subprocess
from fastapi.testclient import TestClient
from main import app, jobs

client = TestClient(app)

def create_dummy_mp4(filename: str, duration_sec: int = 2, with_audio: bool = True):
    """Uses ffmpeg (or fallback binary header) to generate a valid test MP4 clip."""
    if os.path.exists(filename):
        return filename

    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", f"testsrc=duration={duration_sec}:size=640x360:rate=24",
    ]
    if with_audio:
        cmd.extend(["-f", "lavfi", "-i", f"sine=frequency=1000:duration={duration_sec}"])
        cmd.extend(["-c:a", "aac"])
    cmd.extend(["-c:v", "libx264", "-pix_fmt", "yuv420p", filename])

    try:
        subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    except Exception:
        # Fallback binary mock file with valid ftyp box
        with open(filename, "wb") as f:
            f.write(b'\x00\x00\x00 ftypisom\x00\x00\x02\x00isomisommp41\x00\x00\x00\x08free')
            f.write(b'\x00' * 10240)
    return filename

def test_1_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "SK MUZAMMEL 10K" in data["service"]

def test_2_short_mp4_enhancement():
    test_file = create_dummy_mp4("/tmp/test_short.mp4", duration_sec=1, with_audio=False)
    with open(test_file, "rb") as f:
        response = client.post(
            "/api/enhance",
            files={"video": ("test_short.mp4", f, "video/mp4")},
            data={
                "target_resolution": "1080p FHD",
                "model": "Real-ESRGAN",
                "fps_60": "true",
                "watermark": "true"
            }
        )
    assert response.status_code == 200
    data = response.json()
    assert "job_id" in data
    assert data["status"] in ["QUEUED", "PROCESSING"]
    job_id = data["job_id"]

    # Poll until complete or max 15 seconds
    completed = False
    for _ in range(15):
        poll = client.get(f"/api/jobs/{job_id}")
        assert poll.status_code == 200
        pdata = poll.json()
        if pdata["status"] == "COMPLETED":
            completed = True
            break
        time.sleep(1)

    assert completed, "Enhancement job failed to complete in time"

    # Test download
    dl_resp = client.get(f"/api/jobs/{job_id}/download")
    assert dl_resp.status_code == 200
    assert len(dl_resp.content) > 0

def test_3_video_with_audio():
    test_file = create_dummy_mp4("/tmp/test_audio.mp4", duration_sec=2, with_audio=True)
    with open(test_file, "rb") as f:
        response = client.post(
            "/api/enhance",
            files={"video": ("test_audio.mp4", f, "video/mp4")},
            data={
                "target_resolution": "720p HD",
                "model": "AI HDR Color Balance",
                "fps_60": "false",
                "watermark": "true"
            }
        )
    assert response.status_code == 200
    data = response.json()
    job_id = data["job_id"]

    for _ in range(15):
        poll = client.get(f"/api/jobs/{job_id}")
        if poll.json()["status"] == "COMPLETED":
            break
        time.sleep(1)

    assert jobs[job_id]["status"] == "COMPLETED"

def test_4_unsupported_file_rejected():
    with open("/tmp/invalid.txt", "w") as f:
        f.write("Not a video")
    with open("/tmp/invalid.txt", "rb") as f:
        response = client.post(
            "/api/enhance",
            files={"video": ("invalid.txt", f, "text/plain")},
            data={"target_resolution": "1080p FHD"}
        )
    assert response.status_code == 400

def test_5_cancellation_and_cleanup():
    test_file = create_dummy_mp4("/tmp/test_cancel.mp4", duration_sec=1)
    with open(test_file, "rb") as f:
        response = client.post(
            "/api/enhance",
            files={"video": ("test_cancel.mp4", f, "video/mp4")},
            data={"target_resolution": "4K UHD"}
        )
    job_id = response.json()["job_id"]
    del_resp = client.delete(f"/api/jobs/{job_id}")
    assert del_resp.status_code == 200
    assert job_id not in jobs

if __name__ == "__main__":
    print("Running verification suite...")
    test_1_health_check()
    print("✓ Health check passed")
    test_2_short_mp4_enhancement()
    print("✓ Short MP4 enhancement & download passed")
    test_3_video_with_audio()
    print("✓ Video with audio enhancement passed")
    test_4_unsupported_file_rejected()
    print("✓ Unsupported format rejected passed")
    test_5_cancellation_and_cleanup()
    print("✓ Cancellation and cleanup passed")
    print("All tests successfully completed!")
