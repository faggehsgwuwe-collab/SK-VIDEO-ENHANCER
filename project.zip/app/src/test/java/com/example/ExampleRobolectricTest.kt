package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.example.engine.BitmapFilterProcessor
import com.example.localization.AppLanguage
import com.example.localization.StringsLocalization
import com.example.model.EnhancementConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SK VIDEO ENHANCER", appName)
  }

  @Test
  fun `test localization dictionary`() {
    val enTitle = StringsLocalization.get("app_title", AppLanguage.ENGLISH)
    val bnTitle = StringsLocalization.get("app_title", AppLanguage.BENGALI)
    assertEquals("SK VIDEO ENHANCER", enTitle)
    assertEquals("এসকে ভিডিও এনহ্যান্সার", bnTitle)
  }

  @Test
  fun `test bitmap filter processor`() {
    val bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
    val config = EnhancementConfig(sharpness = 1.2f, contrast = 1.2f, vibrance = 1.3f)
    val enhanced = BitmapFilterProcessor.processBitmap(bitmap, config, 120, 120)
    assertNotNull(enhanced)
    assertEquals(120, enhanced.width)
    assertEquals(120, enhanced.height)
  }
}
