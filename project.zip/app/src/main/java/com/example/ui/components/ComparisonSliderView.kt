package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlin.math.roundToInt

enum class ComparisonMode {
    SPLIT_SLIDER,
    SIDE_BY_SIDE
}

@Composable
fun ComparisonSliderView(
    originalUri: String,
    enhancedUri: String,
    modifier: Modifier = Modifier,
    watermarkText: String = "SK MUZAMMEL 10K",
    showWatermark: Boolean = true
) {
    var mode by remember { mutableStateOf(ComparisonMode.SPLIT_SLIDER) }
    var sliderRatio by remember { mutableFloatStateOf(0.5f) }

    Column(modifier = modifier) {
        // Mode Selector Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = mode == ComparisonMode.SPLIT_SLIDER,
                    onClick = { mode = ComparisonMode.SPLIT_SLIDER },
                    label = { Text("Split Slider", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricBlue.copy(alpha = 0.2f),
                        selectedLabelColor = ElectricCyan
                    )
                )
                FilterChip(
                    selected = mode == ComparisonMode.SIDE_BY_SIDE,
                    onClick = { mode = ComparisonMode.SIDE_BY_SIDE },
                    label = { Text("Side by Side", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricBlue.copy(alpha = 0.2f),
                        selectedLabelColor = ElectricCyan
                    )
                )
            }

            Surface(
                color = SurfaceCard,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "AI Enhanced 4K",
                    color = ElectricCyan,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }

        if (mode == ComparisonMode.SPLIT_SLIDER) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(16.dp))
                    .background(BackgroundDark)
            ) {
                val boxWidthPx = constraints.maxWidth.toFloat()

                // Enhanced Video as Base layer
                VideoPlayerView(
                    uriOrPath = enhancedUri,
                    modifier = Modifier.fillMaxSize(),
                    showWatermark = showWatermark,
                    watermarkText = watermarkText
                )

                // Original Video overlay clipped to slider position
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawWithContent {
                            val clipWidth = size.width * sliderRatio
                            drawContent()
                        }
                )

                // Tags for Original and Enhanced
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = "ORIGINAL", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(ElectricBlue.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = "AI ENHANCED", color = Color.White, fontSize = 10.sp)
                }

                // Drag Divider Handle
                val handleOffsetXPx = boxWidthPx * sliderRatio
                Box(
                    modifier = Modifier
                        .offset { IntOffset(handleOffsetXPx.roundToInt() - 16.dp.roundToPx(), 0) }
                        .fillMaxHeight()
                        .width(32.dp)
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val newRatio = (sliderRatio + dragAmount.x / boxWidthPx).coerceIn(0.05f, 0.95f)
                                sliderRatio = newRatio
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // Vertical Line
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(2.dp)
                            .background(ElectricCyan)
                    )

                    // Center Knob
                    Surface(
                        modifier = Modifier.size(32.dp),
                        shape = CircleShape,
                        color = BackgroundDark,
                        border = androidx.compose.foundation.BorderStroke(2.dp, ElectricCyan)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "Drag to compare",
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // Side-by-side mode
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Original column
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp))
                    ) {
                        VideoPlayerView(
                            uriOrPath = originalUri,
                            modifier = Modifier.fillMaxSize(),
                            showWatermark = false
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "Original", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                        }
                    }
                }

                // Enhanced column
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0x5500D2FF), RoundedCornerShape(12.dp))
                    ) {
                        VideoPlayerView(
                            uriOrPath = enhancedUri,
                            modifier = Modifier.fillMaxSize(),
                            showWatermark = showWatermark,
                            watermarkText = watermarkText
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(6.dp)
                                .background(ElectricBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "AI Enhanced", color = Color.White, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}
