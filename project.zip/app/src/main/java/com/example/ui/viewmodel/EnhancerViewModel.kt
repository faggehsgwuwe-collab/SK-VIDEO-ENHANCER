package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.AiModel
import com.example.data.model.EnhancementJob
import com.example.data.model.VideoMetadata
import com.example.data.repository.VideoEnhanceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavScreen {
    SPLASH,
    MAIN,
    RESULT_DETAIL
}

enum class MainTab {
    HOME,
    HISTORY,
    SETTINGS
}

class EnhancerViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = VideoEnhanceRepository(application, database.jobDao())

    // Navigation & Screen States
    private val _currentScreen = MutableStateFlow(AppNavScreen.SPLASH)
    val currentScreen: StateFlow<AppNavScreen> = _currentScreen.asStateFlow()

    private val _selectedTab = MutableStateFlow(MainTab.HOME)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    // Language: "en" or "bn"
    private val _appLanguage = MutableStateFlow("en")
    val appLanguage: StateFlow<String> = _appLanguage.asStateFlow()

    // Video Selection & Config
    private val _selectedVideoUri = MutableStateFlow<Uri?>(null)
    val selectedVideoUri: StateFlow<Uri?> = _selectedVideoUri.asStateFlow()

    private val _videoMetadata = MutableStateFlow<VideoMetadata?>(null)
    val videoMetadata: StateFlow<VideoMetadata?> = _videoMetadata.asStateFlow()

    private val _isAnalyzingVideo = MutableStateFlow(false)
    val isAnalyzingVideo: StateFlow<Boolean> = _isAnalyzingVideo.asStateFlow()

    private val _targetResolution = MutableStateFlow("1080p FHD")
    val targetResolution: StateFlow<String> = _targetResolution.asStateFlow()

    private val _selectedAiModel = MutableStateFlow(AiModel.REAL_ESRGAN)
    val selectedAiModel: StateFlow<AiModel> = _selectedAiModel.asStateFlow()

    private val _interpolate60Fps = MutableStateFlow(true)
    val interpolate60Fps: StateFlow<Boolean> = _interpolate60Fps.asStateFlow()

    private val _applyWatermark = MutableStateFlow(true)
    val applyWatermark: StateFlow<Boolean> = _applyWatermark.asStateFlow()

    // Active Processing Job
    private val _activeJobId = MutableStateFlow<String?>(null)
    val activeJobId: StateFlow<String?> = _activeJobId.asStateFlow()

    private val _activeJob = MutableStateFlow<EnhancementJob?>(null)
    val activeJob: StateFlow<EnhancementJob?> = _activeJob.asStateFlow()

    // Inspection / Detail Job
    private val _inspectingJob = MutableStateFlow<EnhancementJob?>(null)
    val inspectingJob: StateFlow<EnhancementJob?> = _inspectingJob.asStateFlow()

    // All Jobs for History
    val historyJobs: StateFlow<List<EnhancementJob>> = repository.getAllJobs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Server Settings
    private val _serverUrl = MutableStateFlow(repository.currentServerUrl)
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    private val _serverTestResult = MutableStateFlow<String?>(null)
    val serverTestResult: StateFlow<String?> = _serverTestResult.asStateFlow()

    private val _isTestingServer = MutableStateFlow(false)
    val isTestingServer: StateFlow<Boolean> = _isTestingServer.asStateFlow()

    private val _forceStandalone = MutableStateFlow(false)
    val forceStandalone: StateFlow<Boolean> = _forceStandalone.asStateFlow()

    // Download/Toast Feedback
    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    fun dismissSplash() {
        _currentScreen.value = AppNavScreen.MAIN
    }

    fun selectTab(tab: MainTab) {
        _selectedTab.value = tab
    }

    fun setLanguage(lang: String) {
        _appLanguage.value = lang
    }

    fun setTargetResolution(resolution: String) {
        _targetResolution.value = resolution
    }

    fun setSelectedAiModel(model: AiModel) {
        _selectedAiModel.value = model
    }

    fun setInterpolate60Fps(enabled: Boolean) {
        _interpolate60Fps.value = enabled
    }

    fun setApplyWatermark(enabled: Boolean) {
        _applyWatermark.value = enabled
    }

    fun setForceStandalone(enabled: Boolean) {
        _forceStandalone.value = enabled
    }

    fun setServerUrl(url: String) {
        _serverUrl.value = url
        repository.updateServerUrl(url)
    }

    fun clearFeedbackMessage() {
        _feedbackMessage.value = null
    }

    fun onVideoSelected(uri: Uri) {
        _selectedVideoUri.value = uri
        viewModelScope.launch {
            _isAnalyzingVideo.value = true
            val metadata = repository.extractVideoMetadata(uri)
            _videoMetadata.value = metadata
            _isAnalyzingVideo.value = false
        }
    }

    fun loadSampleClip() {
        viewModelScope.launch {
            _isAnalyzingVideo.value = true
            val sampleUri = repository.createOrGetSampleVideo()
            _selectedVideoUri.value = sampleUri
            val metadata = repository.extractVideoMetadata(sampleUri) ?: VideoMetadata(
                uriString = sampleUri.toString(),
                fileName = "sample_gameplay_clip.mp4",
                width = 1280,
                height = 720,
                durationMs = 12500L,
                frameRate = 30f,
                sizeBytes = 1450000L
            )
            _videoMetadata.value = metadata
            _isAnalyzingVideo.value = false
        }
    }

    fun startEnhance() {
        val uri = _selectedVideoUri.value ?: return
        val metadata = _videoMetadata.value ?: return

        viewModelScope.launch {
            val jobId = repository.startEnhancement(
                inputUri = uri,
                metadata = metadata,
                targetResolution = _targetResolution.value,
                aiModel = _selectedAiModel.value.displayName,
                interpolate60Fps = _interpolate60Fps.value,
                applyWatermark = _applyWatermark.value,
                forceStandalone = _forceStandalone.value
            )
            _activeJobId.value = jobId

            // Observe this active job
            repository.getJobFlow(jobId).collect { job ->
                _activeJob.value = job
                if (job?.status == "COMPLETED") {
                    _inspectingJob.value = job
                    _currentScreen.value = AppNavScreen.RESULT_DETAIL
                }
            }
        }
    }

    fun cancelActiveJob() {
        val jobId = _activeJobId.value ?: return
        viewModelScope.launch {
            repository.cancelJob(jobId)
            _activeJobId.value = null
            _activeJob.value = null
        }
    }

    fun openJobDetail(job: EnhancementJob) {
        _inspectingJob.value = job
        _currentScreen.value = AppNavScreen.RESULT_DETAIL
    }

    fun closeJobDetail() {
        _currentScreen.value = AppNavScreen.MAIN
        _inspectingJob.value = null
    }

    fun deleteJob(job: EnhancementJob) {
        viewModelScope.launch {
            repository.deleteJob(job)
            if (_inspectingJob.value?.jobId == job.jobId) {
                closeJobDetail()
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearAllJobs()
        }
    }

    fun downloadCurrentVideo() {
        val job = _inspectingJob.value ?: return
        viewModelScope.launch {
            val (success, message) = repository.saveVideoToDeviceStorage(job)
            _feedbackMessage.value = if (success) {
                "Saved successfully: $message"
            } else {
                "Failed to save video: $message"
            }
        }
    }

    fun testServerConnection() {
        viewModelScope.launch {
            _isTestingServer.value = true
            val (success, message) = repository.testServerConnection()
            _serverTestResult.value = if (success) "✓ $message" else "✗ $message"
            _isTestingServer.value = false
        }
    }
}
