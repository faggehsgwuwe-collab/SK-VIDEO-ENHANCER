package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF001F29),
    primaryContainer = Color(0xFF004D61),
    onPrimaryContainer = Color(0xFFBBE9FF),
    secondary = NeonPurple,
    onSecondary = Color(0xFF2C0051),
    secondaryContainer = Color(0xFF5B1194),
    onSecondaryContainer = Color(0xFFEFDBFF),
    tertiary = NeonPink,
    onTertiary = Color(0xFF5A0027),
    background = GamingDarkBackground,
    onBackground = GamingTextPrimary,
    surface = GamingSurface,
    onSurface = GamingTextPrimary,
    surfaceVariant = GamingCard,
    onSurfaceVariant = GamingTextSecondary,
    outline = GamingCardBorder,
    outlineVariant = Color(0xFF25334D)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Gaming apps benefit from tailored neon cyber color styling
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
