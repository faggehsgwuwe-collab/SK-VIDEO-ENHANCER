package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SkDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = BackgroundDark,
    primaryContainer = SurfaceCard,
    onPrimaryContainer = ElectricCyan,
    secondary = NeonSapphire,
    onSecondary = TextPrimary,
    secondaryContainer = SurfaceDark,
    onSecondaryContainer = ElectricBlue,
    tertiary = CyberPurple,
    onTertiary = TextPrimary,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = BorderGlow,
    error = ErrorRed,
    onError = TextPrimary
)

@Composable
fun SkVideoEnhancerTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SkDarkColorScheme,
        typography = Typography,
        content = content
    )
}
