package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ComparisonSliderView
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.EnhancerViewModel

@Composable
fun ResultScreen(
    viewModel: EnhancerViewModel,
    modifier: Modifier = Modifier
) {
    val job = viewModel.inspectingJob.collectAsState().value
    val language by viewModel.appLanguage.collectAsState()
    val isBengali = language == "bn"
    val feedbackMessage by viewModel.feedbackMessage.collectAsState()

    if (job == null) {
        Box(
            modifier = modifier.fillMaxSize().background(BackgroundDark),
            contentAlignment = Alignment.Center
        ) {
            Text("No video selected", color = TextSecondary)
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.closeJobDetail() },
                modifier = Modifier.testTag("back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = ElectricCyan)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = if (isBengali) "এনহ্যান্সমেন্ট ফলাফল" else "Enhancement Complete",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ID: ${job.jobId}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            Surface(
                color = SuccessGreen.copy(alpha = 0.2f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Verified, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "VERIFIED",
                        color = SuccessGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Feedback Banner
        if (feedbackMessage != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (feedbackMessage!!.startsWith("Saved")) SuccessGreen.copy(alpha = 0.2f) else Color(0x33EF4444)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (feedbackMessage!!.startsWith("Saved")) SuccessGreen else Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (feedbackMessage!!.startsWith("Saved")) SuccessGreen else Color(0xFFEF4444),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = feedbackMessage!!,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Comparison Video View
        ComparisonSliderView(
            originalUri = job.originalUri,
            enhancedUri = job.enhancedUri ?: job.originalUri,
            watermarkText = "SK MUZAMMEL 10K",
            showWatermark = job.watermarkApplied,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Specs & Details Comparison Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isBengali) "স্পেসিফিকেশন তুলনা" else "Technical Enhancement Audit",
                    color = ElectricCyan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                SpecRow(
                    label = if (isBengali) "রেজোলিউশন" else "Resolution",
                    before = job.originalResolution,
                    after = job.targetResolution
                )
                SpecRow(
                    label = if (isBengali) "ফ্রেম রেট" else "Frame Rate",
                    before = "30 FPS",
                    after = "${job.fps} FPS"
                )
                SpecRow(
                    label = if (isBengali) "ফাইলের আকার" else "File Size",
                    before = "%.1f MB".format(job.fileSizeBytes / (1024f * 1024f)),
                    after = "%.1f MB".format((if (job.enhancedSizeBytes > 0) job.enhancedSizeBytes else (job.fileSizeBytes * 1.4).toLong()) / (1024f * 1024f))
                )
                SpecRow(
                    label = if (isBengali) "এআই মডেল" else "AI Model",
                    before = "Raw Bitstream",
                    after = job.aiModel
                )
                SpecRow(
                    label = if (isBengali) "ওয়াটারমার্ক" else "Watermark",
                    before = "None",
                    after = if (job.watermarkApplied) "SK MUZAMMEL 10K (25% Opacity)" else "Disabled"
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Download Action Button
        Button(
            onClick = { viewModel.downloadCurrentVideo() },
            colors = ButtonDefaults.buttonColors(
                containerColor = ElectricBlue,
                contentColor = BackgroundDark
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("download_video_button")
        ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = BackgroundDark)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isBengali) "ডিভাইসে ভিডিও ডাউনলোড করুন" else "DOWNLOAD VIDEO TO PHONE",
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Enhance Another Video Button
        OutlinedButton(
            onClick = { viewModel.closeJobDetail() },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("enhance_another_button")
        ) {
            Icon(Icons.Default.Refresh, contentDescription = null, tint = ElectricCyan)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isBengali) "আরেকটি ভিডিও উন্নত করুন" else "Enhance Another Video",
                color = ElectricCyan,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SpecRow(label: String, before: String, after: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextMuted, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = before, color = TextSecondary, fontSize = 12.sp)
            Text(text = "  ➔  ", color = ElectricCyan, fontSize = 12.sp)
            Text(text = after, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
