package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.StringsLocalization
import com.example.model.EnhancementConfig
import com.example.model.ProcessingEngineType
import com.example.model.VideoFramerate
import com.example.model.VideoResolution
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.viewmodel.GamingPreset

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GamingControls(
    config: EnhancementConfig,
    language: AppLanguage,
    onConfigChange: (EnhancementConfig) -> Unit,
    onPresetSelect: (GamingPreset) -> Unit,
    onOpenServerSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Esports Presets Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ElectricBolt,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = StringsLocalization.get("gaming_presets", language),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GamingPreset.entries.forEach { preset ->
                        PresetChip(
                            label = StringsLocalization.get(preset.labelKey, language),
                            onClick = { onPresetSelect(preset) }
                        )
                    }
                }
            }
        }

        // Resolution & Framerate Selectors
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Resolution
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HighQuality,
                        contentDescription = null,
                        tint = NeonPurple,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = StringsLocalization.get("output_resolution", language),
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    VideoResolution.entries.forEach { res ->
                        val selected = config.resolution == res
                        SelectableButton(
                            text = res.label,
                            selected = selected,
                            modifier = Modifier.weight(1f),
                            onClick = { onConfigChange(config.copy(resolution = res)) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Framerate
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = StringsLocalization.get("target_framerate", language),
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    VideoFramerate.entries.forEach { fps ->
                        val selected = config.framerate == fps
                        SelectableButton(
                            text = fps.label,
                            selected = selected,
                            modifier = Modifier.weight(1f),
                            onClick = { onConfigChange(config.copy(framerate = fps)) }
                        )
                    }
                }
            }
        }

        // Enhancement Sliders Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = StringsLocalization.get("enhancement_parameters", language),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Sharpness
                ControlSlider(
                    label = StringsLocalization.get("sharpness", language),
                    value = config.sharpness,
                    range = 0.0f..2.0f,
                    valueText = "%.2fx".format(config.sharpness),
                    onValueChange = { onConfigChange(config.copy(sharpness = it)) }
                )

                // Contrast
                ControlSlider(
                    label = StringsLocalization.get("contrast", language),
                    value = config.contrast,
                    range = 0.8f..2.0f,
                    valueText = "%.2fx".format(config.contrast),
                    onValueChange = { onConfigChange(config.copy(contrast = it)) }
                )

                // Vibrance
                ControlSlider(
                    label = StringsLocalization.get("vibrance", language),
                    value = config.vibrance,
                    range = 0.8f..2.0f,
                    valueText = "%.2fx".format(config.vibrance),
                    onValueChange = { onConfigChange(config.copy(vibrance = it)) }
                )

                // Brightness
                ControlSlider(
                    label = StringsLocalization.get("brightness", language),
                    value = config.brightness,
                    range = -0.2f..0.35f,
                    valueText = if (config.brightness >= 0) "+%.2f".format(config.brightness) else "%.2f".format(config.brightness),
                    onValueChange = { onConfigChange(config.copy(brightness = it)) }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Denoise Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = StringsLocalization.get("denoise", language),
                        color = Color(0xFFE2E8F0),
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = config.noiseReduction,
                        onCheckedChange = { onConfigChange(config.copy(noiseReduction = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = Color(0xFF005166)
                        )
                    )
                }

                // HDR Gaming Grade Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = StringsLocalization.get("hdr_game", language),
                        color = Color(0xFFE2E8F0),
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = config.hdrGamingGrade,
                        onCheckedChange = { onConfigChange(config.copy(hdrGamingGrade = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonPurple,
                            checkedTrackColor = Color(0xFF52188A)
                        )
                    )
                }
            }
        }

        // Engine & Server Configuration Link
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Dns,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = StringsLocalization.get("engine_mode", language),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Text(
                        text = StringsLocalization.get("server_settings", language),
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clickable { onOpenServerSettings() }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SelectableButton(
                        text = "Native Engine",
                        selected = config.engineType == ProcessingEngineType.NATIVE_ENGINE,
                        modifier = Modifier.weight(1f),
                        onClick = { onConfigChange(config.copy(engineType = ProcessingEngineType.NATIVE_ENGINE)) }
                    )
                    SelectableButton(
                        text = "Remote AI Server",
                        selected = config.engineType == ProcessingEngineType.REMOTE_AI_SERVER,
                        modifier = Modifier.weight(1f),
                        onClick = { onConfigChange(config.copy(engineType = ProcessingEngineType.REMOTE_AI_SERVER)) }
                    )
                }
            }
        }
    }
}

@Composable
fun PresetChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFF1E293B), Color(0xFF162033))
                )
            )
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun SelectableButton(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (selected) Brush.horizontalGradient(listOf(Color(0xFF006B80), Color(0xFF5B1194)))
                else Brush.horizontalGradient(listOf(Color(0xFF141D2E), Color(0xFF141D2E)))
            )
            .border(
                1.dp,
                if (selected) NeonCyan else Color(0xFF243247),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else Color(0xFF94A3B8),
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

@Composable
fun ControlSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                color = Color(0xFFCBD5E1),
                fontSize = 12.sp
            )
            Text(
                text = valueText,
                color = NeonCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = Color(0xFF26354D)
            ),
            modifier = Modifier.height(28.dp)
        )
    }
}
