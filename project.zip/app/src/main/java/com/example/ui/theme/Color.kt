package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Gaming Dark Navy & Electric Blue Palette
val BackgroundDark = Color(0xFF070A12)
val BackgroundNavy = Color(0xFF0B1329)
val SurfaceDark = Color(0xFF0F1B38)
val SurfaceCard = Color(0xFF14234B)
val SurfaceGlass = Color(0xCC101D3D)
val BorderGlow = Color(0x4000D2FF)

val ElectricBlue = Color(0xFF00D2FF)
val ElectricCyan = Color(0xFF00F5D4)
val NeonSapphire = Color(0xFF3A86FF)
val CyberPurple = Color(0xFF8338EC)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AccentGold = Color(0xFFFFBE0B)
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
