package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SK Video Enhancer Cyberpunk / Gaming Palette
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanGlow = Color(0x3300F0FF)
val NeonPurple = Color(0xFFA855F7)
val NeonPurpleGlow = Color(0x33A855F7)
val NeonPink = Color(0xFFEC4899)
val NeonGreen = Color(0xFF10B981)
val NeonAmber = Color(0xFFF59E0B)

val GamingDarkBackground = Color(0xFF080B14)
val GamingSurface = Color(0xFF0F172A)
val GamingCard = Color(0xFF141E33)
val GamingCardBorder = Color(0xFF1E293B)
val GamingTextPrimary = Color(0xFFF8FAFC)
val GamingTextSecondary = Color(0xFF94A3B8)
val GamingTextMuted = Color(0xFF64748B)

val FreeFireRed = Color(0xFFFF2A55)
val FreeFireGold = Color(0xFFFFC107)
