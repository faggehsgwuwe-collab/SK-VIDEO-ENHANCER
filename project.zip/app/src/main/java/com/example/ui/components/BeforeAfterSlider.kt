package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.StringsLocalization
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import kotlin.math.roundToInt

@Composable
fun BeforeAfterSlider(
    originalBitmap: Bitmap?,
    enhancedBitmap: Bitmap?,
    language: AppLanguage,
    modifier: Modifier = Modifier,
    initialSplit: Float = 0.5f,
    onSplitChanged: ((Float) -> Unit)? = null
) {
    var splitFraction by remember(initialSplit) { mutableFloatStateOf(initialSplit) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0A0F1D))
            .border(1.5.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
            .testTag("before_after_slider_container")
    ) {
        val totalWidthPx = constraints.maxWidth.toFloat()
        val totalHeightPx = constraints.maxHeight.toFloat()

        if (originalBitmap != null && enhancedBitmap != null) {
            // Enhanced image is in background (full)
            Image(
                bitmap = enhancedBitmap.asImageBitmap(),
                contentDescription = StringsLocalization.get("preview_enhanced", language),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Original image is clipped to the left side up to splitFraction
            val splitPx = totalWidthPx * splitFraction
            Image(
                bitmap = originalBitmap.asImageBitmap(),
                contentDescription = StringsLocalization.get("preview_original", language),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        val clipRect = Rect(0f, 0f, splitPx, size.height)
                        val path = Path().apply { addRect(clipRect) }
                        clipPath(path) {
                            this@drawWithContent.drawContent()
                        }
                    }
            )

            // Neon divider vertical line
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        drawContent()
                        drawLine(
                            color = NeonCyan,
                            start = Offset(splitPx, 0f),
                            end = Offset(splitPx, size.height),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
            )

            // Touch Drag Handle
            Box(
                modifier = Modifier
                    .offset { IntOffset((splitPx - 20.dp.toPx()).roundToInt(), (totalHeightPx / 2 - 20.dp.toPx()).roundToInt()) }
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0F172A))
                    .border(2.dp, NeonCyan, CircleShape)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val newPx = (splitPx + dragAmount.x).coerceIn(10f, totalWidthPx - 10f)
                            splitFraction = newPx / totalWidthPx
                            onSplitChanged?.invoke(splitFraction)
                        }
                    }
                    .testTag("slider_handle"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CompareArrows,
                    contentDescription = "Drag to compare",
                    tint = NeonCyan,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Left Badge: ORIGINAL
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xCC000000))
                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = StringsLocalization.get("preview_original", language),
                    color = Color.White,
                    fontSize = 11.sp,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            // Right Badge: ENHANCED (AI)
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xDD0F172A))
                    .border(1.dp, NeonCyan, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = StringsLocalization.get("preview_enhanced", language),
                    color = NeonCyan,
                    fontSize = 11.sp,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            // Bottom Hint
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xB3080B14))
                    .padding(horizontal = 12.dp, vertical = 3.dp)
            ) {
                Text(
                    text = StringsLocalization.get("slide_to_compare", language),
                    color = Color(0xFFCBD5E1),
                    fontSize = 10.sp
                )
            }
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = StringsLocalization.get("processing_analyzing", language),
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
            }
        }
    }
}
