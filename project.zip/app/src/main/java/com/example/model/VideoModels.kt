package com.example.model

import android.net.Uri

enum class VideoResolution(val label: String, val width: Int, val height: Int) {
    RES_720P("720p HD", 1280, 720),
    RES_1080P("1080p Full HD", 1920, 1080),
    RES_4K("4K Ultra HD", 3840, 2160)
}

enum class VideoFramerate(val label: String, val fps: Int) {
    FPS_30("30 FPS", 30),
    FPS_60("60 FPS (Ultra Smooth)", 60)
}

enum class ProcessingEngineType {
    NATIVE_ENGINE,
    REMOTE_AI_SERVER
}

data class VideoInfo(
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val fps: Int = 30,
    val isSample: Boolean = false
) {
    val formattedDuration: String
        get() {
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return "%02d:%02d".format(minutes, seconds)
        }

    val formattedSize: String
        get() {
            val mb = sizeBytes / (1024.0 * 1024.0)
            return if (mb >= 1.0) "%.1f MB".format(mb) else "%.1f KB".format(sizeBytes / 1024.0)
        }

    val resolutionLabel: String
        get() = "${width}x${height}"
}

data class EnhancementConfig(
    val resolution: VideoResolution = VideoResolution.RES_1080P,
    val framerate: VideoFramerate = VideoFramerate.FPS_60,
    val sharpness: Float = 1.3f, // 0.0f to 2.0f
    val contrast: Float = 1.25f, // 0.8f to 2.0f
    val vibrance: Float = 1.35f, // 0.8f to 2.0f
    val brightness: Float = 0.08f, // -0.3f to 0.4f
    val noiseReduction: Boolean = true,
    val hdrGamingGrade: Boolean = true,
    val engineType: ProcessingEngineType = ProcessingEngineType.NATIVE_ENGINE,
    val serverUrl: String = "http://10.0.2.2:5000"
)

enum class ProcessingStatus {
    IDLE,
    ANALYZING,
    PROCESSING,
    ENCODING,
    COMPLETED,
    CANCELLED,
    ERROR
}

data class ProcessingProgress(
    val status: ProcessingStatus = ProcessingStatus.IDLE,
    val currentFrame: Int = 0,
    val totalFrames: Int = 0,
    val progressFraction: Float = 0f,
    val elapsedSeconds: Long = 0,
    val remainingSeconds: Long = 0,
    val statusMessage: String = "",
    val outputVideoUri: Uri? = null,
    val outputSizeBytes: Long = 0L,
    val errorMessage: String? = null
)
