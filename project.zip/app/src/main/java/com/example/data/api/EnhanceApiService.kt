package com.example.data.api

import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Streaming

data class JobStatusResponse(
    val job_id: String,
    val status: String,
    val progress: Float,
    val stage: String,
    val original_resolution: String? = null,
    val target_resolution: String? = null,
    val duration_seconds: Float? = null,
    val watermark_applied: Boolean? = true,
    val download_url: String? = null,
    val error_message: String? = null
)

data class HealthResponse(
    val status: String,
    val service: String,
    val ffmpeg_available: Boolean,
    val ai_model_loaded: Boolean,
    val version: String
)

interface EnhanceApiService {
    @GET("health")
    suspend fun checkHealth(): Response<HealthResponse>

    @Multipart
    @POST("api/enhance")
    suspend fun uploadAndEnhance(
        @Part video: MultipartBody.Part,
        @Part("target_resolution") targetResolution: RequestBody,
        @Part("model") model: RequestBody,
        @Part("fps_60") fps60: RequestBody,
        @Part("watermark") watermark: RequestBody
    ): Response<JobStatusResponse>

    @GET("api/jobs/{job_id}")
    suspend fun getJobStatus(
        @Path("job_id") jobId: String
    ): Response<JobStatusResponse>

    @Streaming
    @GET("api/jobs/{job_id}/download")
    suspend fun downloadVideo(
        @Path("job_id") jobId: String
    ): Response<ResponseBody>

    @DELETE("api/jobs/{job_id}")
    suspend fun cancelJob(
        @Path("job_id") jobId: String
    ): Response<Map<String, Any>>
}
