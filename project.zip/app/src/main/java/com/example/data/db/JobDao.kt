package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.EnhancementJob
import kotlinx.coroutines.flow.Flow

@Dao
interface JobDao {
    @Query("SELECT * FROM enhancement_jobs ORDER BY timestamp DESC")
    fun getAllJobsFlow(): Flow<List<EnhancementJob>>

    @Query("SELECT * FROM enhancement_jobs WHERE jobId = :jobId LIMIT 1")
    suspend fun getJobById(jobId: String): EnhancementJob?

    @Query("SELECT * FROM enhancement_jobs WHERE jobId = :jobId LIMIT 1")
    fun getJobByIdFlow(jobId: String): Flow<EnhancementJob?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: EnhancementJob)

    @Update
    suspend fun updateJob(job: EnhancementJob)

    @Delete
    suspend fun deleteJob(job: EnhancementJob)

    @Query("DELETE FROM enhancement_jobs WHERE jobId = :jobId")
    suspend fun deleteJobById(jobId: String)

    @Query("DELETE FROM enhancement_jobs")
    suspend fun clearAllJobs()
}
