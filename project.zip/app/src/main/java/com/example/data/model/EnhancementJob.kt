package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "enhancement_jobs")
data class EnhancementJob(
    @PrimaryKey val jobId: String,
    val fileName: String,
    val originalUri: String,
    val enhancedUri: String?,
    val originalResolution: String,
    val targetResolution: String,
    val aiModel: String,
    val fps: Int,
    val fileSizeBytes: Long,
    val enhancedSizeBytes: Long,
    val watermarkApplied: Boolean,
    val status: String, // "QUEUED", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED"
    val progress: Float, // 0.0f to 1.0f
    val stageDescription: String,
    val timestamp: Long = System.currentTimeMillis(),
    val errorMessage: String? = null
)

enum class JobStatus {
    QUEUED,
    UPLOADING,
    EXTRACTING_FRAMES,
    AI_ENHANCING,
    WATERMARKING_ENCODING,
    VERIFYING,
    COMPLETED,
    FAILED,
    CANCELLED
}

enum class AiModel(val displayName: String, val description: String) {
    REAL_ESRGAN("Real-ESRGAN", "Deep neural AI super-resolution and edge detail synthesis"),
    DENOISE_SHARPEN("AI Denoise & Sharpen", "Advanced spatio-temporal grain removal and micro-contrast"),
    HDR_COLOR("AI HDR Color Balance", "Dynamic color grading, shadow recovery, and vivid tones"),
    FAST_FFMPEG("Fast FFmpeg Engine", "High-speed hardware lane with Lanczos upscale and unsharp filter")
}

data class VideoMetadata(
    val uriString: String,
    val fileName: String,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val frameRate: Float,
    val sizeBytes: Long
)
