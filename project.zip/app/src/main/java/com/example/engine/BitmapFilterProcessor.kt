package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.example.model.EnhancementConfig
import kotlin.math.max
import kotlin.math.min

object BitmapFilterProcessor {

    /**
     * Applies real visual enhancement filters including:
     * - Color matrix grading (saturation, contrast, brightness, HDR game boost)
     * - Resolution scaling (super-resolution bicubic upscaling)
     * - Pixel-level unsharp masking / Laplacian edge sharpening
     */
    fun processBitmap(
        src: Bitmap,
        config: EnhancementConfig,
        targetWidth: Int = config.resolution.width,
        targetHeight: Int = config.resolution.height
    ): Bitmap {
        // 1. Scale to target resolution with bilinear/bicubic filtering
        val scaled = if (src.width != targetWidth || src.height != targetHeight) {
            // Maintain aspect ratio or scale to fit
            val srcAspect = src.width.toFloat() / src.height.toFloat()
            val targetAspect = targetWidth.toFloat() / targetHeight.toFloat()
            val finalW: Int
            val finalH: Int
            if (srcAspect > targetAspect) {
                finalW = targetWidth
                finalH = max(2, (targetWidth / srcAspect).toInt() and 1.inv())
            } else {
                finalH = targetHeight
                finalW = max(2, (targetHeight * srcAspect).toInt() and 1.inv())
            }
            Bitmap.createScaledBitmap(src, finalW, finalH, true)
        } else {
            src.copy(Bitmap.Config.ARGB_8888, true)
        }

        // 2. Color grading & contrast matrix
        val result = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

        val matrix = ColorMatrix()

        // Saturation / Vibrance boost
        val satMatrix = ColorMatrix()
        satMatrix.setSaturation(config.vibrance)

        // Contrast and Brightness
        val contrast = config.contrast
        val brightnessShift = config.brightness * 255f
        val t = (1.0f - contrast) / 2.0f * 255.0f

        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, t + brightnessShift,
                0f, contrast, 0f, 0f, t + brightnessShift,
                0f, 0f, contrast, 0f, t + brightnessShift,
                0f, 0f, 0f, 1f, 0f
            )
        )

        // Combine saturation & contrast
        matrix.postConcat(satMatrix)
        matrix.postConcat(contrastMatrix)

        // HDR Gaming Color Grade: boost reds and cyan highlights (Free Fire Bermuda aesthetic)
        if (config.hdrGamingGrade) {
            val hdrMatrix = ColorMatrix(
                floatArrayOf(
                    1.10f, 0f, 0f, 0f, 8f,
                    0f, 1.05f, 0f, 0f, 4f,
                    0f, 0f, 1.15f, 0f, 10f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.postConcat(hdrMatrix)
        }

        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(scaled, 0f, 0f, paint)

        // 3. Pixel-level Unsharp Masking (Anti-blur & Sharpness)
        if (config.sharpness > 0.3f) {
            applyUnsharpMask(result, config.sharpness)
        }

        if (scaled != src && scaled != result) {
            scaled.recycle()
        }

        return result
    }

    /**
     * High-speed in-place 3x3 unsharp convolution kernel on Bitmap.
     * Uses Laplacian high-pass difference to enhance edges, gun textures, crosshair, and foliage.
     */
    private fun applyUnsharpMask(bitmap: Bitmap, sharpness: Float) {
        val width = bitmap.width
        val height = bitmap.height
        val size = width * height
        val pixels = IntArray(size)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val output = IntArray(size)
        val weight = min(2.5f, sharpness * 0.75f)

        // Sample every row except borders for safety
        for (y in 1 until height - 1) {
            val rowOffset = y * width
            val prevRowOffset = (y - 1) * width
            val nextRowOffset = (y + 1) * width

            for (x in 1 until width - 1) {
                val center = pixels[rowOffset + x]
                val left = pixels[rowOffset + x - 1]
                val right = pixels[rowOffset + x + 1]
                val top = pixels[prevRowOffset + x]
                val bottom = pixels[nextRowOffset + x]

                val cr = (center shr 16) and 0xFF
                val cg = (center shr 8) and 0xFF
                val cb = center and 0xFF

                val lr = (left shr 16) and 0xFF
                val lg = (left shr 8) and 0xFF
                val lb = left and 0xFF

                val rr = (right shr 16) and 0xFF
                val rg = (right shr 8) and 0xFF
                val rb = right and 0xFF

                val tr = (top shr 16) and 0xFF
                val tg = (top shr 8) and 0xFF
                val tb = top and 0xFF

                val br = (bottom shr 16) and 0xFF
                val bg = (bottom shr 8) and 0xFF
                val bb = bottom and 0xFF

                // Laplacian high-pass
                val avgR = (lr + rr + tr + br) shr 2
                val avgG = (lg + rg + tg + bg) shr 2
                val avgB = (lb + rb + tb + bb) shr 2

                val newR = min(255, max(0, (cr + (cr - avgR) * weight).toInt()))
                val newG = min(255, max(0, (cg + (cg - avgG) * weight).toInt()))
                val newB = min(255, max(0, (cb + (cb - avgB) * weight).toInt()))

                output[rowOffset + x] = (-0x1000000) or (newR shl 16) or (newG shl 8) or newB
            }
            // Fill borders
            output[rowOffset] = pixels[rowOffset]
            output[rowOffset + width - 1] = pixels[rowOffset + width - 1]
        }

        // Copy top & bottom rows
        System.arraycopy(pixels, 0, output, 0, width)
        System.arraycopy(pixels, (height - 1) * width, output, (height - 1) * width, width)

        bitmap.setPixels(output, 0, width, 0, 0, width, height)
    }
}
