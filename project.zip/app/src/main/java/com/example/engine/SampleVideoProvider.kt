package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.model.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.sin

object SampleVideoProvider {

    private const val SAMPLE_FILE_NAME = "free_fire_gameplay_sample.mp4"

    suspend fun getOrCreateSampleVideo(context: Context): VideoInfo = withContext(Dispatchers.IO) {
        val sampleFile = File(context.filesDir, SAMPLE_FILE_NAME)
        if (!sampleFile.exists() || sampleFile.length() < 1000) {
            generateSyntheticGameplayVideo(sampleFile)
        }

        val uri = Uri.fromFile(sampleFile)
        VideoInfo(
            uri = uri,
            title = "Free_Fire_Ranked_Highlight.mp4",
            durationMs = 5000L,
            width = 1280,
            height = 720,
            sizeBytes = sampleFile.length(),
            fps = 30,
            isSample = true
        )
    }

    /**
     * Generates a 5-second 720p 30fps Free Fire gameplay action video
     * with animated HUD, crosshair, radar, and health bar.
     */
    private fun generateSyntheticGameplayVideo(outputFile: File) {
        val width = 1280
        val height = 720
        val fps = 30
        val durationSeconds = 5
        val totalFrames = fps * durationSeconds
        val bitRate = 3_000_000 // 3 Mbps

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var trackIndex = -1
        var muxerStarted = false

        val bufferInfo = MediaCodec.BufferInfo()
        val frameBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(frameBitmap)
        val yuvBuffer = ByteArray(width * height * 3 / 2)
        val argbPixels = IntArray(width * height)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        try {
            var frameCount = 0
            while (frameCount < totalFrames) {
                // 1. Draw synthetic Free Fire gameplay scene
                drawGameplayFrame(canvas, width, height, frameCount, totalFrames, paint)

                // 2. Convert ARGB to YUV420
                frameBitmap.getPixels(argbPixels, 0, width, 0, 0, width, height)
                encodeYUV420SP(yuvBuffer, argbPixels, width, height)

                // 3. Feed to encoder
                val inputIndex = encoder.dequeueInputBuffer(10000L)
                if (inputIndex >= 0) {
                    val inputBuffer = encoder.getInputBuffer(inputIndex)
                    inputBuffer?.clear()
                    inputBuffer?.put(yuvBuffer)
                    val pts = (frameCount * 1_000_000L / fps)
                    encoder.queueInputBuffer(inputIndex, 0, yuvBuffer.size, pts, 0)
                    frameCount++
                }

                // 4. Drain encoder output
                var outputIndex = encoder.dequeueOutputBuffer(bufferInfo, 0L)
                while (outputIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(outputIndex)
                    if (encodedData != null && bufferInfo.size > 0) {
                        if (!muxerStarted) {
                            trackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outputIndex, false)
                    outputIndex = encoder.dequeueOutputBuffer(bufferInfo, 0L)
                }
            }

            // Signal EOS
            val eosIndex = encoder.dequeueInputBuffer(10000L)
            if (eosIndex >= 0) {
                val pts = (totalFrames * 1_000_000L / fps)
                encoder.queueInputBuffer(eosIndex, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }

            // Drain remaining
            while (true) {
                val outputIndex = encoder.dequeueOutputBuffer(bufferInfo, 10000L)
                if (outputIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(outputIndex)
                    if (encodedData != null && bufferInfo.size > 0) {
                        if (!muxerStarted) {
                            trackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!muxerStarted) {
                        trackIndex = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                } else {
                    break
                }
            }
        } finally {
            try { encoder.stop() } catch (_: Exception) {}
            try { encoder.release() } catch (_: Exception) {}
            if (muxerStarted) {
                try { muxer.stop() } catch (_: Exception) {}
            }
            try { muxer.release() } catch (_: Exception) {}
            frameBitmap.recycle()
        }
    }

    private fun drawGameplayFrame(
        canvas: Canvas,
        w: Int,
        h: Int,
        frame: Int,
        total: Int,
        paint: Paint
    ) {
        // Sky & Terrain gradient
        val skyShader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.rgb(18, 28, 48), Color.rgb(45, 65, 30), Shader.TileMode.CLAMP)
        paint.shader = skyShader
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        paint.shader = null

        // Animated sunlight ray & horizon hills
        paint.color = Color.rgb(24, 40, 20)
        val hillPath = Path().apply {
            moveTo(0f, h * 0.55f)
            lineTo(w * 0.3f, h * 0.48f)
            lineTo(w * 0.7f, h * 0.52f)
            lineTo(w.toFloat(), h * 0.45f)
            lineTo(w.toFloat(), h.toFloat())
            lineTo(0f, h.toFloat())
            close()
        }
        canvas.drawPath(hillPath, paint)

        // Building / Obstacle in Bermuda map
        paint.color = Color.rgb(85, 90, 100)
        canvas.drawRect(w * 0.45f, h * 0.35f, w * 0.65f, h * 0.75f, paint)
        paint.color = Color.rgb(40, 45, 55)
        canvas.drawRect(w * 0.47f, h * 0.40f, w * 0.52f, h * 0.50f, paint)

        // Free Fire HUD - Mini Map (top right)
        paint.color = Color.argb(200, 15, 23, 42)
        canvas.drawRoundRect(w - 180f, 20f, w - 20f, 180f, 20f, 20f, paint)
        paint.color = Color.rgb(0, 240, 255)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawRoundRect(w - 180f, 20f, w - 20f, 180f, 20f, 20f, paint)
        paint.style = Paint.Style.FILL

        // Player marker on radar
        paint.color = Color.rgb(255, 42, 85)
        canvas.drawCircle(w - 100f, 100f, 8f, paint)

        // Match Info: "ALIVE: 14 | KILLS: 7"
        paint.color = Color.WHITE
        paint.textSize = 28f
        paint.isFakeBoldText = true
        canvas.drawText("ALIVE: 14  KILLS: 7", 40f, 60f, paint)

        // Health Bar (bottom center)
        val barLeft = w * 0.35f
        val barRight = w * 0.65f
        val barTop = h - 70f
        val barBottom = h - 45f

        paint.color = Color.argb(180, 0, 0, 0)
        canvas.drawRoundRect(barLeft - 4f, barTop - 4f, barRight + 4f, barBottom + 4f, 8f, 8f, paint)

        // HP fill
        paint.color = Color.rgb(16, 185, 129)
        canvas.drawRoundRect(barLeft, barTop, barRight - 40f, barBottom, 6f, 6f, paint)

        paint.color = Color.WHITE
        paint.textSize = 20f
        canvas.drawText("HP 180/200", barLeft + 15f, barTop + 19f, paint)

        // Animated Crosshair (center screen with subtle gun recoil movement)
        val recoilY = (sin(frame.toDouble() * 0.3) * 6.0).toFloat()
        val cx = w / 2f
        val cy = (h / 2f) + recoilY

        paint.color = Color.rgb(0, 240, 255)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawCircle(cx, cy, 24f, paint)
        canvas.drawLine(cx - 36f, cy, cx - 12f, cy, paint)
        canvas.drawLine(cx + 12f, cy, cx + 36f, cy, paint)
        canvas.drawLine(cx, cy - 36f, cx, cy - 12f, paint)
        canvas.drawLine(cx, cy + 12f, cx, cy + 36f, paint)

        // Red center dot
        paint.style = Paint.Style.FILL
        paint.color = Color.RED
        canvas.drawCircle(cx, cy, 3f, paint)

        // Weapon badge: "MP40 - POKER"
        paint.color = Color.argb(220, 20, 30, 50)
        canvas.drawRoundRect(w - 240f, h - 90f, w - 20f, h - 30f, 12f, 12f, paint)
        paint.color = Color.rgb(255, 193, 7)
        paint.textSize = 22f
        canvas.drawText("MP40 Flashing Spade", w - 230f, h - 52f, paint)
    }

    private fun encodeYUV420SP(yuv420sp: ByteArray, argb: IntArray, width: Int, height: Int) {
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize

        for (j in 0 until height) {
            for (i in 0 until width) {
                val rgb = argb[j * width + i]
                val r = (rgb shr 16) and 0xff
                val g = (rgb shr 8) and 0xff
                val b = rgb and 0xff

                var y = (66 * r + 129 * g + 25 * b + 128 shr 8) + 16
                var u = (-38 * r - 74 * g + 112 * b + 128 shr 8) + 128
                var v = (112 * r - 94 * g - 18 * b + 128 shr 8) + 128

                y = y.coerceIn(16, 255)
                u = u.coerceIn(0, 255)
                v = v.coerceIn(0, 255)

                yuv420sp[yIndex++] = y.toByte()

                if (j % 2 == 0 && i % 2 == 0) {
                    yuv420sp[uvIndex++] = u.toByte()
                    yuv420sp[uvIndex++] = v.toByte()
                }
            }
        }
    }
}
