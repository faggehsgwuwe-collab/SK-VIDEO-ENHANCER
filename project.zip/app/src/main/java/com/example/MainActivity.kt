package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Splitscreen
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localization.AppLanguage
import com.example.localization.StringsLocalization
import com.example.model.ProcessingStatus
import com.example.ui.components.BackendServerDialog
import com.example.ui.components.BeforeAfterSlider
import com.example.ui.components.GamingControls
import com.example.ui.components.ProcessingOverlay
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.GamingDarkBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.viewmodel.EnhancerViewModel
import java.io.File

class MainActivity : ComponentActivity() {

    private val viewModel: EnhancerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainEnhancerScreen(viewModel = viewModel, onShareVideo = ::shareVideoFile)
            }
        }
    }

    private fun shareVideoFile(videoUri: Uri) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, videoUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Share Enhanced Video"))
        } catch (e: Exception) {
            Toast.makeText(this, "Could not share video: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun MainEnhancerScreen(
    viewModel: EnhancerViewModel,
    onShareVideo: (Uri) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Modern Zero-Permission Photo/Video Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadVideo(it) }
    }

    // Fallback document/file picker
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadVideo(it) }
    }

    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    // 0: Before/After Slider, 1: Original Player, 2: Enhanced Player
    var previewMode by remember { mutableIntStateOf(0) }

    Scaffold(
        containerColor = GamingDarkBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopGamingBar(
                language = uiState.language,
                onLanguageToggle = {
                    val nextLang = if (uiState.language == AppLanguage.ENGLISH) AppLanguage.BENGALI else AppLanguage.ENGLISH
                    viewModel.setLanguage(nextLang)
                },
                onOpenServer = { viewModel.showServerDialog(true) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .widthIn(max = 680.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hero Banner Card
            HeroBannerCard(language = uiState.language)

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons: Select Video & Try Sample
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        } catch (_: Exception) {
                            documentPickerLauncher.launch("video/*")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0F172A),
                        contentColor = NeonCyan
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .border(1.5.dp, NeonCyan, RoundedCornerShape(12.dp))
                        .testTag("upload_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.UploadFile,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = StringsLocalization.get("select_video", uiState.language),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }

                Button(
                    onClick = { viewModel.loadSampleVideo() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E1638),
                        contentColor = NeonPurple
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .border(1.5.dp, NeonPurple, RoundedCornerShape(12.dp))
                        .testTag("sample_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Games,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = StringsLocalization.get("try_sample", uiState.language),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Active Video Metadata Chip
            uiState.videoInfo?.let { info ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = info.title,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${info.resolutionLabel} • ${info.formattedDuration} • ${info.formattedSize}",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Target Resolution Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF142B38))
                                .border(1.dp, NeonCyan, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "-> ${uiState.config.resolution.label}",
                                color = NeonCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Preview Mode Tabs
            val hasEnhancedVideo = uiState.progress.outputVideoUri != null
            val tabs = listOf(
                StringsLocalization.get("compare_mode", uiState.language),
                StringsLocalization.get("preview_original", uiState.language),
                StringsLocalization.get("preview_enhanced", uiState.language)
            )

            TabRow(
                selectedTabIndex = previewMode,
                containerColor = Color(0xFF0F172A),
                contentColor = NeonCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[previewMode]),
                        color = NeonCyan
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = previewMode == index,
                        onClick = { previewMode = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (previewMode == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (previewMode == index) NeonCyan else Color(0xFF94A3B8)
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visual Display Area based on selected Tab
            when (previewMode) {
                0 -> {
                    // Interactive Before / After Split Slider
                    BeforeAfterSlider(
                        originalBitmap = uiState.originalFrame,
                        enhancedBitmap = uiState.enhancedFrame,
                        language = uiState.language,
                        initialSplit = uiState.splitPosition,
                        onSplitChanged = { viewModel.setSplitPosition(it) }
                    )
                }
                1 -> {
                    // Original Video Player
                    VideoPlayerView(
                        videoUri = uiState.videoInfo?.uri,
                        language = uiState.language,
                        title = StringsLocalization.get("preview_original", uiState.language)
                    )
                }
                2 -> {
                    // Enhanced Video Player
                    val outputUri = uiState.progress.outputVideoUri
                    if (outputUri != null) {
                        VideoPlayerView(
                            videoUri = outputUri,
                            language = uiState.language,
                            title = StringsLocalization.get("preview_enhanced", uiState.language) + " (${uiState.config.resolution.label})"
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(240.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0B0F1D))
                                .border(1.5.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.HighQuality,
                                    contentDescription = null,
                                    tint = Color(0xFF475569),
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Enhance the video below to view full 4K/60FPS enhanced playback.",
                                    color = Color(0xFF64748B),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Processing Progress Overlay
            ProcessingOverlay(
                progress = uiState.progress,
                isProcessing = uiState.isProcessing,
                videoInfo = uiState.videoInfo,
                language = uiState.language,
                onCancel = { viewModel.cancelEnhancement() },
                onSaveToGallery = { viewModel.saveVideoToGallery() },
                onShareVideo = {
                    uiState.progress.outputVideoUri?.let { uri -> onShareVideo(uri) }
                }
            )

            // Primary Enhance CTA Button (when not processing)
            if (!uiState.isProcessing) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.startEnhancement() },
                    enabled = uiState.videoInfo != null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan,
                        contentColor = Color(0xFF001F29),
                        disabledContainerColor = Color(0xFF1E293B),
                        disabledContentColor = Color(0xFF64748B)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_enhancement_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = StringsLocalization.get("enhance_button", uiState.language),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Gaming Controls Section (Sliders, Presets, Toggles, Server Link)
            GamingControls(
                config = uiState.config,
                language = uiState.language,
                onConfigChange = { viewModel.updateConfig(it) },
                onPresetSelect = { viewModel.applyPreset(it) },
                onOpenServerSettings = { viewModel.showServerDialog(true) }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Backend Server Setup Dialog
        if (uiState.showServerDialog) {
            BackendServerDialog(
                currentUrl = uiState.config.serverUrl,
                serverStatus = uiState.serverStatus,
                language = uiState.language,
                onUrlChange = { newUrl ->
                    viewModel.updateConfig(uiState.config.copy(serverUrl = newUrl))
                },
                onTestConnection = { url ->
                    viewModel.testServerConnection(url)
                },
                onDismiss = { viewModel.showServerDialog(false) }
            )
        }
    }
}

@Composable
fun TopGamingBar(
    language: AppLanguage,
    onLanguageToggle: () -> Unit,
    onOpenServer: () -> Unit
) {
    Surface(
        color = Color(0xFF080B14),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF1E293B))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App Branding & Logo
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.linearGradient(listOf(NeonCyan, NeonPurple))
                        )
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF0B0E17)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = StringsLocalization.get("app_title", language),
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = StringsLocalization.get("app_subtitle", language),
                        color = NeonCyan,
                        fontSize = 10.sp
                    )
                }
            }

            // Language & Server Actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Language Toggle Button: [EN | বাংলা]
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, NeonCyan, RoundedCornerShape(20.dp))
                        .clickable { onLanguageToggle() }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("language_toggle_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Language",
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (language == AppLanguage.ENGLISH) "EN | বাংলা" else "বাংলা | EN",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Server Settings Button
                IconButton(
                    onClick = onOpenServer,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF141D2E))
                        .border(1.dp, Color(0xFF334155), CircleShape)
                        .testTag("server_dialog_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Dns,
                        contentDescription = "Server Settings",
                        tint = NeonPurple,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun HeroBannerCard(language: AppLanguage) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            // Background Image
            Image(
                painter = painterResource(id = R.drawable.free_fire_banner_1793531859767),
                contentDescription = "Free Fire Gaming Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dark gradient overlay for text readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xDD080B14), Color(0x66080B14), Color(0x11080B14))
                        )
                    )
            )

            // Overlay Badges
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xCCFF2A55))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "FREE FIRE ESPORTS EDITION",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column {
                    Text(
                        text = "Unleash Ultra HD Clarity",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Real Unsharp Masking • 60 FPS • Free Fire Color Grading",
                        color = NeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
