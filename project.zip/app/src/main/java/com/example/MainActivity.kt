package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ResultScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BackgroundNavy
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.SkVideoEnhancerTheme
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.AppNavScreen
import com.example.ui.viewmodel.EnhancerViewModel
import com.example.ui.viewmodel.MainTab

class MainActivity : ComponentActivity() {

    private val viewModel: EnhancerViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SkVideoEnhancerTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()
                val selectedTab by viewModel.selectedTab.collectAsState()
                val language by viewModel.appLanguage.collectAsState()
                val isBengali = language == "bn"

                // Handle system back navigation
                BackHandler {
                    when {
                        currentScreen == AppNavScreen.RESULT_DETAIL -> {
                            viewModel.closeJobDetail()
                        }
                        selectedTab != MainTab.HOME -> {
                            viewModel.selectTab(MainTab.HOME)
                        }
                        else -> {
                            finish()
                        }
                    }
                }

                Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                    when (screen) {
                        AppNavScreen.SPLASH -> {
                            SplashScreen(
                                onContinue = { viewModel.dismissSplash() }
                            )
                        }
                        AppNavScreen.RESULT_DETAIL -> {
                            ResultScreen(
                                viewModel = viewModel,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .windowInsetsPadding(WindowInsets.statusBars)
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                            )
                        }
                        AppNavScreen.MAIN -> {
                            Scaffold(
                                topBar = {
                                    TopBarHeader(isBengali = isBengali)
                                },
                                bottomBar = {
                                    BottomNavBar(
                                        selectedTab = selectedTab,
                                        isBengali = isBengali,
                                        onSelectTab = { viewModel.selectTab(it) }
                                    )
                                },
                                containerColor = BackgroundDark,
                                contentWindowInsets = WindowInsets(0, 0, 0, 0)
                            ) { innerPadding ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(innerPadding)
                                ) {
                                    when (selectedTab) {
                                        MainTab.HOME -> HomeScreen(viewModel = viewModel)
                                        MainTab.HISTORY -> HistoryScreen(viewModel = viewModel)
                                        MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBarHeader(isBengali: Boolean) {
    Surface(
        color = BackgroundNavy,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .border(1.dp, BorderGlow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, ElectricCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "SK Video Enhancer",
                        tint = ElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = "SK VIDEO ENHANCER",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (isBengali) "এআই ভিডিও রিস্টোরেশন" else "AI Ultra-Resolution",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Surface(
                color = ElectricBlue.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "SK MUZAMMEL 10K",
                    color = ElectricCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
fun BottomNavBar(
    selectedTab: MainTab,
    isBengali: Boolean,
    onSelectTab: (MainTab) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = BackgroundNavy,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = selectedTab == MainTab.HOME,
            onClick = { onSelectTab(MainTab.HOME) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Enhance"
                )
            },
            label = {
                Text(
                    text = if (isBengali) "উন্নত করুন" else "Enhance",
                    fontSize = 11.sp,
                    fontWeight = if (selectedTab == MainTab.HOME) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BackgroundDark,
                selectedTextColor = ElectricCyan,
                indicatorColor = ElectricCyan,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_tab_home")
        )

        NavigationBarItem(
            selected = selectedTab == MainTab.HISTORY,
            onClick = { onSelectTab(MainTab.HISTORY) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.HISTORY) Icons.Filled.History else Icons.Outlined.History,
                    contentDescription = "History"
                )
            },
            label = {
                Text(
                    text = if (isBengali) "ইতিহাস" else "History",
                    fontSize = 11.sp,
                    fontWeight = if (selectedTab == MainTab.HISTORY) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BackgroundDark,
                selectedTextColor = ElectricCyan,
                indicatorColor = ElectricCyan,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_tab_history")
        )

        NavigationBarItem(
            selected = selectedTab == MainTab.SETTINGS,
            onClick = { onSelectTab(MainTab.SETTINGS) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == MainTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings"
                )
            },
            label = {
                Text(
                    text = if (isBengali) "সেটিংস" else "Settings",
                    fontSize = 11.sp,
                    fontWeight = if (selectedTab == MainTab.SETTINGS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BackgroundDark,
                selectedTextColor = ElectricCyan,
                indicatorColor = ElectricCyan,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_tab_settings")
        )
    }
}
