package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.BitmapFilterProcessor
import com.example.engine.SampleVideoProvider
import com.example.engine.VideoProcessingEngine
import com.example.localization.AppLanguage
import com.example.model.EnhancementConfig
import com.example.model.ProcessingEngineType
import com.example.model.ProcessingProgress
import com.example.model.ProcessingStatus
import com.example.model.VideoFramerate
import com.example.model.VideoInfo
import com.example.model.VideoResolution
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class GamingPreset(val labelKey: String) {
    FREE_FIRE_ULTRA("preset_freefire"),
    PRO_SHARP_4K("preset_sharp"),
    VIBRANT_COLOR("preset_vibrant"),
    NIGHT_VISION("preset_night")
}

data class EnhancerUiState(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val videoInfo: VideoInfo? = null,
    val originalFrame: Bitmap? = null,
    val enhancedFrame: Bitmap? = null,
    val splitPosition: Float = 0.5f,
    val config: EnhancementConfig = EnhancementConfig(),
    val progress: ProcessingProgress = ProcessingProgress(),
    val isProcessing: Boolean = false,
    val showServerDialog: Boolean = false,
    val serverStatus: String? = null,
    val toastMessage: String? = null,
    val activeTab: Int = 0 // 0: Enhance & Compare, 1: Player & Controls, 2: Server & Guide
)

class EnhancerViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = VideoProcessingEngine(application)

    private val _uiState = MutableStateFlow(EnhancerUiState())
    val uiState: StateFlow<EnhancerUiState> = _uiState.asStateFlow()

    private var enhancementJob: Job? = null

    init {
        // Automatically preload the Free Fire sample video so the user has immediate visual content
        viewModelScope.launch {
            loadSampleVideo()
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _uiState.update { it.copy(language = lang) }
    }

    fun setActiveTab(tab: Int) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun setSplitPosition(position: Float) {
        _uiState.update { it.copy(splitPosition = position.coerceIn(0f, 1f)) }
    }

    fun showServerDialog(show: Boolean) {
        _uiState.update { it.copy(showServerDialog = show) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    fun loadVideo(uri: Uri) {
        viewModelScope.launch {
            try {
                val info = engine.analyzeVideo(uri)
                val rawFrame = engine.extractPreviewFrame(uri, info.durationMs / 3 * 1000L)
                val enhanced = rawFrame?.let {
                    BitmapFilterProcessor.processBitmap(it, _uiState.value.config)
                }

                _uiState.update {
                    it.copy(
                        videoInfo = info,
                        originalFrame = rawFrame,
                        enhancedFrame = enhanced,
                        progress = ProcessingProgress()
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(toastMessage = "Error opening video: ${e.message}") }
            }
        }
    }

    fun loadSampleVideo() {
        viewModelScope.launch {
            try {
                val info = SampleVideoProvider.getOrCreateSampleVideo(getApplication())
                val rawFrame = engine.extractPreviewFrame(info.uri, 1_500_000L)
                val enhanced = rawFrame?.let {
                    BitmapFilterProcessor.processBitmap(it, _uiState.value.config)
                }

                _uiState.update {
                    it.copy(
                        videoInfo = info,
                        originalFrame = rawFrame,
                        enhancedFrame = enhanced,
                        progress = ProcessingProgress()
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(toastMessage = "Failed to load sample: ${e.message}") }
            }
        }
    }

    fun updateConfig(config: EnhancementConfig) {
        _uiState.update { it.copy(config = config) }
        reprocessPreviewFrame()
    }

    fun applyPreset(preset: GamingPreset) {
        val current = _uiState.value.config
        val updated = when (preset) {
            GamingPreset.FREE_FIRE_ULTRA -> current.copy(
                resolution = VideoResolution.RES_1080P,
                framerate = VideoFramerate.FPS_60,
                sharpness = 1.45f,
                contrast = 1.30f,
                vibrance = 1.45f,
                brightness = 0.08f,
                hdrGamingGrade = true,
                noiseReduction = true
            )
            GamingPreset.PRO_SHARP_4K -> current.copy(
                resolution = VideoResolution.RES_4K,
                framerate = VideoFramerate.FPS_60,
                sharpness = 1.80f,
                contrast = 1.25f,
                vibrance = 1.20f,
                brightness = 0.05f,
                hdrGamingGrade = true,
                noiseReduction = true
            )
            GamingPreset.VIBRANT_COLOR -> current.copy(
                resolution = VideoResolution.RES_1080P,
                framerate = VideoFramerate.FPS_30,
                sharpness = 1.10f,
                contrast = 1.20f,
                vibrance = 1.65f,
                brightness = 0.06f,
                hdrGamingGrade = true,
                noiseReduction = false
            )
            GamingPreset.NIGHT_VISION -> current.copy(
                resolution = VideoResolution.RES_1080P,
                framerate = VideoFramerate.FPS_60,
                sharpness = 1.35f,
                contrast = 1.45f,
                vibrance = 1.15f,
                brightness = 0.22f, // Lift dark gameplay shadows
                hdrGamingGrade = false,
                noiseReduction = true
            )
        }
        updateConfig(updated)
    }

    private fun reprocessPreviewFrame() {
        val raw = _uiState.value.originalFrame ?: return
        viewModelScope.launch {
            val enhanced = BitmapFilterProcessor.processBitmap(raw, _uiState.value.config)
            _uiState.update { it.copy(enhancedFrame = enhanced) }
        }
    }

    fun startEnhancement() {
        val video = _uiState.value.videoInfo ?: return
        if (_uiState.value.isProcessing) return

        _uiState.update { it.copy(isProcessing = true) }

        enhancementJob = viewModelScope.launch {
            try {
                val outputUri = engine.enhanceVideo(video, _uiState.value.config) { prog ->
                    _uiState.update { it.copy(progress = prog) }
                }
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        toastMessage = "Video enhancement completed successfully!"
                    )
                }
            } catch (e: Exception) {
                val wasCancelled = e.message?.contains("cancelled", ignoreCase = true) == true
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        toastMessage = if (wasCancelled) "Enhancement cancelled" else "Error: ${e.message}"
                    )
                }
            }
        }
    }

    fun cancelEnhancement() {
        engine.cancel()
        enhancementJob?.cancel()
        _uiState.update {
            it.copy(
                isProcessing = false,
                progress = it.progress.copy(status = ProcessingStatus.CANCELLED)
            )
        }
    }

    fun saveVideoToGallery() {
        val outputUri = _uiState.value.progress.outputVideoUri ?: return
        val title = _uiState.value.videoInfo?.title ?: "enhanced_video.mp4"

        viewModelScope.launch {
            val savedUri = engine.saveVideoToGallery(outputUri, title)
            if (savedUri != null) {
                _uiState.update { it.copy(toastMessage = "Saved to Movies/SKVideoEnhancer in your gallery!") }
            } else {
                _uiState.update { it.copy(toastMessage = "Unable to save to gallery.") }
            }
        }
    }

    fun testServerConnection(url: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(serverStatus = "Testing connection to $url...") }
            val online = engine.testRemoteServer(url)
            _uiState.update {
                it.copy(
                    serverStatus = if (online) "ONLINE: Remote AI Server is ready!"
                    else "OFFLINE: Server unreachable. Native Engine will be used."
                )
            }
        }
    }
}
